﻿SongLed Flasher v0.0.2

Single-file mode only.

Steps:
1. Run SongLedFlasher.exe
2. Connect ESP32-S3 (COM port)
3. Select songled_v0.0.2_merged.bin
4. Click Start Flashing

Flash target:
- Address: 0x0
- Chip: ESP32-S3

Backend:
- Priority 1: esptool.exe in current folder
- Priority 2: python + esptool.py in current folder

If using python mode, Python 3 must be available in PATH.
