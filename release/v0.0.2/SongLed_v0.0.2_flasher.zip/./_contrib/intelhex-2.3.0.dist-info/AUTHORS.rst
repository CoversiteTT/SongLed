Author: Alexander Belchenko

Copyright (C) Alexander Belchenko, 2005-2018

Special thanks to Bernhard Leiner for huge help in porting
IntelHex library to Python 3.

Contributors:

* Alexander Belchenko
* Alex Mueller
* Andrew Fernandes
* Bernhard Leiner
* Enoch H. Wexler
* Heiko Henkelmann
* Henrik Maier
* Masayuki Takeda
* Morgan McClure
* Nathan P. Stien
* Piotr Korowacki
* Reis Baltaoglu
* Ryan Downing
* Scott Armitage
* Stefan Schmitt
* Theo Sbrissa
* Zachary Clifford
* "durexyl" @ GitHub
* "erki1993" @ GitHub
* "mentaal" @ GitHub
